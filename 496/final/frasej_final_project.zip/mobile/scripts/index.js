﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener( 'resume', onResume.bind( this ), false );

        $('#go-to-movies-btn').click(function () {
            if ($('#username').val() && $('#password').val()) {
                location.href = '#-page1'
            }
        });


        //Handle click event for get weather button
        $('#post-seller-btn').click(postStore);

        $('#get-store-movie-btn').click(function () {
            getStoreMovie();
        });

        $('#get-store-movie-btn-2').click(function () {
            getStoreMovie();
        });

        $('#put-movie-in-store-btn').click(addStoreMovie);


        $('#list-seller-btn').click(function () {
            postStoreList();
        });

        $(document).on('click', '.delete', function(){
            event.stopPropagation();
            var url = $(this).parent().attr('id') + "/delete"
            deleteStore(url);
        });

        $(document).on('click', '.deleteFrom', function () {
            event.stopPropagation();
            var url = "http://store-api-148707.appspot.com/store/" + $('#key').val() + "/movie/delete/" + $("#sellerMovies option:selected").val() ;
            deleteStore(url);
        });

        $('#post-movie-btn').click(postMovie);

        $('#list-movie-btn').click(function () {
            postMovieList();
        });

        $(document).on('click', '.deleteMovie', function () {
            event.stopPropagation();
            var url = $(this).parent().attr('id') + "/delete"
            deleteMovie(url);
        });

        $(document).on('click', 'span', function () {
            //stop propogation for buttons inside the list item
            if ($(event.target).is('.delete')) {
                event.stopPropagation();
                return;
            }

            //make sure that the list is only sids for if and mids for movies
            if ($(event.target).attr('class') == "link") {
                getStore($(this).parent().attr('id'));
            }
            else if ($(event.target).attr('class') == "movielink") {
                getMovie($(this).parent().attr('id'));
            }
        });


        getAddressWithGeoLocation();
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };
} )();