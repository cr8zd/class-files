function postMovie() {

    $('#movie-data').hide();
    $('#movie-list').hide();
    $('#error-msg-movie').hide();

    var movietitle = encodeURIComponent($('#title').val());
    var moviestyle = encodeURIComponent($('#style').val());
    var movieprice = encodeURIComponent($('#price').val());
    var moviedesc = encodeURIComponent($('#desc').val());
    var username = encodeURIComponent($('#username').val());
    var password = encodeURIComponent($('#password').val());
    var mid = encodeURIComponent($('#mid').val());

    if (username.length && password.length) {
        if (mid.length) {
            var moviedata = { 'mid': mid };

            if (movieprice.length) {
                moviedata['price'] = movieprice;
            }

            if (moviedesc.length) {
                moviedata['desc'] = moviedesc;
            }

            $.ajax({
                accept: "application/json",
                type: "PUT",
                url: 'http://store-api-148707.appspot.com/movie/change',
                contentType: "application/x-www-form-urlencoded",
                dataType: "json",
                data: moviedata,
                success: function (data) {
                    console.log(data);
                    showMovieData(data);
                },
                error: function (jqXHR) {
                    $('#error-msg-movie').show();
                    $('#error-msg-movie').text("Error putting data. " + jqXHR.statusText);
                }
            });
        }
        else {
            if (movietitle.length && movieprice.length && moviestyle.length) {
                var moviedata = { 'title': movietitle };
                moviedata['username'] = username;
                moviedata['password'] = password;
                moviedata['price'] = movieprice;
                moviedata['style'] = moviestyle;
                if (moviedesc.length) {
                    moviedata['desc'] = moviedesc;
                }

                $.ajax({
                    accept: "application/json",
                    type: "POST",
                    url: 'http://store-api-148707.appspot.com/movie',
                    contentType: "application/x-www-form-urlencoded",
                    dataType: "json",
                    data: moviedata,
                    success: function (data) {
                        console.log(data);
                        showMovieData(data);
                    },
                    error: function (jqXHR) {
                        $('#error-msg-movie').show();
                        $('#error-msg-movie').text("Error posting data. " + jqXHR.statusText);
                    }
                });
            }
            else {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error: movie title, style, and price are required");
            }
        }
    }
    else{
        $('#error-msg').show();
        $('#error-msg').text("Error: username and password are required");
    }
    return false;
}

function postMovieList() {
    $('#movie-data').hide();
    $('#error-msg-movie').hide();

    var username = encodeURIComponent($('#username').val());
    var password = encodeURIComponent($('#password').val());

    if (username.length && password.length) {
        var moviedata = { 'username': username };
        moviedata['password'] = password;
        
        $.ajax({
            accept: "application/json",
            type: "POST",
            url: 'http://store-api-148707.appspot.com/movie/search',
            contentType: "application/x-www-form-urlencoded",
            dataType: "json",
            data: moviedata,
            success: function (data) {
                console.log(data);
                showMovies(data);
            },
            error: function (jqXHR) {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error posting data. " + jqXHR.statusText);
            }
        });
    }
}

function getMovie(url) {
    if (url.length) {
        $.ajax({
            accept: "application/json",
            type: "GET",
            url: url,
            success: function (data) {
                console.log(data);
                showMovies(jQuery.parseJSON(data));
            },
            error: function (jqXHR) {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error getting data. " + jqXHR.statusText);
            }
        });
    }
    else {
        $('#error-msg-movie').show();
        $('#error-msg-movie').text("Error get requires URL");
    }

    return false;
}

function showMovies(results) {
    $('#attributes').hide();
    $('#description').hide();
    if (results) {
        if (results.title) {
            showUpdateMovieData(results)
        }
        else {
            $('#movie-data').hide();
            $('#movie-list').show();
            $('#movie-list').empty();

            removeMovieInput("Add Movie");
            $('#movie-list').append('<li data-role="list-divider" id="movieList" class="ui-li-divider ui-bar-a"> Keys: </li>');
            $.each(results.keys, function (index, value) {
                var url = "http://store-api-148707.appspot.com/movie/" + value;
                var $newli = $("<li id=" + url + ">&nbsp" + index + ": <span  class = 'movielink'>" + value + "</span>" +
                    "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp" +
                    "<button class ='deleteMovie'>delete</button></li>");
                $('#movie-list').append($newli);
            });
        }
    }
    else {
        $('#movie-data').hide();
        $('#error-msg-movie').show();
        $('#error-msg-movie').text("Error retrieving data. ");
    }
}

function showUpdateMovieData(results) {

    $('#attributes').hide();
    $('#description').hide();
    $('#movie-list').show();
    $('#movie-data').hide();
    $('#error-msg-movie').hide();
    if (results) {

        removeMovieInput("Update Movie");
        $('#post-movie-btn').prop('disabled', true);

        //add results to the bottom of the page
        $('#title').val(decodeURIComponent(results.title));
        $('#title').prop('disabled', true);
        $('#style').val(decodeURIComponent(results.style));
        $('#style').prop('disabled', true);
        $('#price').val(decodeURIComponent(results.price));
        $('#mid').val(results.key);
        if (decodeURIComponent(results.desc)) {
            $('#desc').val(results.desc);
        }
    }
    else {
        $('#movie-data').hide();
        $('#error-msg-movie').show();
        $('#error-msg-movie').text("Error retrieving data. ");
    }
}

function showMovieData(results){
    $('#attributes').hide();
    $('#description').hide();
    if (results) {

        removeMovieInput("Add Movie");
        $('#post-movie-btn').prop('disabled', false);

        $('#movie-data').show();

        $('#movietitle').text(decodeURIComponent(results.title));
        $('#mid').text(results.key);
        $('#atrributes').show();
        $('#movieStyle').text(results.style);
        $('#attributes').show();
        $('#description').show();
        $('#moviePrice').text(results.price);
        if (results.desc) {
            $('#description').show();
            $('#movieDesc').text(results.desc);
        }
    }
    else {
        $('#movie-data').hide();
        $('#error-msg-movie').show();
        $('#error-msg-movie').text("Error retrieving data. ");
    }
}


function deleteMovie(url) {
    removeMovieInput("Add Movie");
    if (url.length) {
        $.ajax({
            type: "DELETE",
            url: url,
            success: function (data) {
                postMovieList();
                alert(data);
            },
            error: function (jqXHR) {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error deleting data. " + jqXHR.statusText);
            }
        });
    }
    else {
        $('#error-msg-movie').show();
        $('#error-msg-movie').text("Error delete requires URL");
    }
    return false;
}

function removeMovieInput(button) {
    //remove values in form
    $('#title').val('');
    $('#title').prop('disabled', false);
    $('#style').val('');
    $('#style').prop('disabled', false);
    $('#price').val('');
    $('#desc').val('');
    $('#mid').val(''); //in case of change

    //change value of button
    $('#post-movie-btn').prop('disabled', false);
    $('#post-movie-btn').text(button);
}

function checkMovieState() {
    if ($('#mid').length) {
        $('#post-movie-btn').text("Update Movie");
    }
    else {
        $('#post-movie-btn').text("Add Movie");
    }
}

function getStoreMovie() {


    var username = encodeURIComponent($('#username').val());
    var password = encodeURIComponent($('#password').val());

    if (username.length && password.length) {
        var moviedata = { 'username': username };
        moviedata['password'] = password;

        $.ajax({
            accept: "application/json",
            type: "POST",
            url: 'http://store-api-148707.appspot.com/movie/search',
            contentType: "application/x-www-form-urlencoded",
            dataType: "json",
            data: moviedata,
            success: function (mdata) {
                console.log(mdata);
                var storedata = { 'username': username };
                storedata['password'] = password;

                $.ajax({
                    accept: "application/json",
                    type: "POST",
                    url: 'http://store-api-148707.appspot.com/store/search',
                    contentType: "application/x-www-form-urlencoded",
                    dataType: "json",
                    data: storedata,
                    success: function (sdata) {
                        console.log(sdata);
                        $('#movie-select').empty();
                        $('#movie-select').append('<option val="None" selected="selected">&nbsp&nbsp</option>');
                        $('#store-select').empty();
                        $('#store-select').append('<option val="None" selected="selected">&nbsp&nbsp</option>');
                        $.each(mdata.keys, function (mindex, mvalue) {
                            $('#movie-select').append('<option val="' + mvalue + '">' + mvalue + '</option>');
                        });
                        $.each(sdata.keys, function (sindex, svalue) {
                            $('#store-select').append('<option val="' + svalue + '">' + svalue + '</option>');
                        });
                    },
                    error: function (jqXHR) {
                        $('#error-msg-movie').show();
                        $('#error-msg-movie').text("Error posting data. " + jqXHR.statusText);
                    }
                });
            },
            error: function (jqXHR) {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error posting data. " + jqXHR.statusText);
            }
        });
    }
/*
    $.ajax({
        accept: "application/json",
        type: "GET",
        url: "http://store-api-148707.appspot.com/movie",
        success: function (moviedata) {
            //got movie data
            $.ajax({
                accept: "application/json",
                type: "GET",
                url: "http://store-api-148707.appspot.com/store",
                success: function (storedata) {
                    //got store and movie data
                    console.log(storedata);
                    console.log(moviedata);
                    //populate select on third page
                    $('#movie-select').empty();
                    $('#movie-select').append('<option val="None" selected="selected">&nbsp&nbsp</option>');
                    $('#store-select').empty();
                    $('#store-select').append('<option val="None" selected="selected">&nbsp&nbsp</option>');
                    $.each(jQuery.parseJSON(moviedata).keys, function (mindex, mvalue) {
                        $('#movie-select').append('<option val="' + mvalue + '">' + mvalue + '</option>');
                    });
                    $.each(jQuery.parseJSON(storedata).keys, function (sindex, svalue) {
                        $('#store-select').append('<option val="' + svalue + '">' + svalue + '</option>');
                    });
                },
                error: function (jqXHR) {
                    $('#error-msg').show();
                    $('#error-msg').text("Error getting seller data. " + jqXHR.statusText);
                }
            });
        },
        error: function (jqXHR) {
            $('#error-msg').show();
            $('#error-msg').text("Error getting movie data. " + jqXHR.statusText);
        }
    });
*/
}