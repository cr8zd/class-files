﻿var GeoCodeKey = "AIzaSyBQ13yY3i3ym4eURVKXDDann2kRNL-h4Ic";

function postStore() {

    $('#seller-data').hide();
    $('#error-msg').hide();

    var sellerName = encodeURIComponent($('#name').val());
    var sellerLine1 = encodeURIComponent($('#line1').val());
    var sellerLine2 = encodeURIComponent($('#line2').val());
    var sellerCity = encodeURIComponent($('#city').val());
    var sellerState = encodeURIComponent($('#state').val());
    var sellerCountry = encodeURIComponent($('#country').val());
    var sellerZip = encodeURIComponent($('#zip').val());
    var sellerPhone = encodeURIComponent($('#phone').val());
    var username = encodeURIComponent($('#username').val());
    var password = encodeURIComponent($('#password').val());
    var key = encodeURIComponent($('#key').val());

    if (username.length && password.length) {
        if (key.length) {
            var sellerdata = { 'sid': key };

            if (sellerPhone.length) {
                sellerdata['phone'] = sellerPhone;
            }

            if (sellerLine1.length && sellerCity.length && sellerCountry.length && sellerZip.length && sellerState.length) {

                sellerdata['line1'] = sellerLine1;
                sellerdata['city'] = sellerCity;
                sellerdata['state'] = sellerState;
                sellerdata['country'] = sellerCountry;
                sellerdata['zipCode'] = sellerZip;
                if (sellerLine2.length) {
                    sellerdata['line2'] = sellerLine2;
                }
            }
            else if (sellerLine1.length || sellerCity.length || sellerCountry.length || sellerZip.length || sellerState.length) {
                $('#error-msg').show();
                $('#error-msg').text("Error: incomplete address needs street, city, state, zip, and country");
            }

            $.ajax({
                accept: "application/json",
                type: "PUT",
                url: 'http://store-api-148707.appspot.com/store/change',
                contentType: "application/x-www-form-urlencoded",
                dataType: "json",
                data: sellerdata,
                success: function (data) {
                    console.log(data);
                    showSellerData(data);
                },
                error: function (jqXHR) {
                    $('#error-msg').show();
                    $('#error-msg').text("Error putting data. " + jqXHR.statusText);
                }
            });
        }
        else {
            if (sellerName.length) {
                var sellerdata = { 'name': sellerName };
                sellerdata['username'] = username;
                sellerdata['password'] = password;

                if (sellerPhone.length) {
                    sellerdata['phone'] = sellerPhone;
                }

                if (sellerLine1.length && sellerCity.length && sellerCountry.length && sellerZip.length && sellerState.length) {

                    sellerdata['line1'] = sellerLine1;
                    sellerdata['city'] = sellerCity;
                    sellerdata['state'] = sellerState;
                    sellerdata['country'] = sellerCountry;
                    sellerdata['zipCode'] = sellerZip;
                    if (sellerLine2.length) {
                        sellerdata['line2'] = sellerLine2;
                    }
                }
                else if (sellerLine1.length || sellerCity.length || sellerCountry.length || sellerZip.length || sellerState.length) {
                    $('#error-msg').show();
                    $('#error-msg').text("Error: incomplete address needs street, city, state, zip, and country");
                }

                $.ajax({
                    accept: "application/json",
                    type: "POST",
                    url: 'http://store-api-148707.appspot.com/store',
                    contentType: "application/x-www-form-urlencoded",
                    dataType: "json",
                    data: sellerdata,
                    success: function (data) {
                        console.log(data);
                        showSellerData(data);
                    },
                    error: function (jqXHR) {
                        $('#error-msg').show();
                        $('#error-msg').text("Error posting data. " + jqXHR.statusText);
                    }
                });
            }
            else {
                $('#error-msg').show();
                $('#error-msg').text("Error: name is required");
            }
        }
    }
    else {
        $('#error-msg').show();
        $('#error-msg').text("Error: username and password are required");
    }
    return false;
}

function getAddressWithGeoLocation() {
    navigator.geolocation.getCurrentPosition(onGetLocationSuccess, onGetLocationError,
      { enableHighAccuracy: true });

    $('#error-msg').show();
    $('#error-msg').text('Address ERROR ...');

    $('#post-seller-btn').prop('disabled', true);
}

function onGetLocationSuccess(position) {

    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;

    var queryString = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='
        + latitude + ',' + longitude + '&key=AIzaSyBQ13yY3i3ym4eURVKXDDann2kRNL-h4Ic';

    $('#post-seller-btn').prop('disabled', false);

    $.get(queryString, function (results) {

        showAddressData(results);

    }).fail(function (jqXHR) {
        $('#error-msg').show();
        $('#error-msg').text("Error retrieving address data. " + jqXHR.statusText);
    });

}

function postStoreList() {
    $('#movie-data').hide();
    $('#error-msg-movie').hide();

    var username = encodeURIComponent($('#username').val());
    var password = encodeURIComponent($('#password').val());

    if (username.length && password.length) {
        var storedata = { 'username': username };
        storedata['password'] = password;

        $.ajax({
            accept: "application/json",
            type: "POST",
            url: 'http://store-api-148707.appspot.com/store/search',
            contentType: "application/x-www-form-urlencoded",
            dataType: "json",
            data: storedata,
            success: function (data) {
                console.log(data);
                showStores(data);
            },
            error: function (jqXHR) {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error posting data. " + jqXHR.statusText);
            }
        });
    }
}


function getStore(url) {
    if (url.length) {
        $.ajax({
            accept: "application/json",
            type: "GET",
            url: url,
            success: function (data) {
                console.log(data);
                showStores(jQuery.parseJSON(data));
            },
            error: function (jqXHR) {
                $('#error-msg').show();
                $('#error-msg').text("Error getting data. " + jqXHR.statusText);
            }
        });
    }
    else {
        $('#error-msg').show();
        $('#error-msg').text("Error get requires URL");
    }
    return false;
}
function showStores(results) {

    $('#sellerAddress1').hide();
    $('#sellerAddress2').hide();
    $('#sellerPhone1').hide();
    $('sellerMovies1').hide();
    if (results) {

        $('#post-seller-btn').prop('disabled', false);
        if (results.name) {
            showUpdateData(results)
        }
        else {
            $('#seller-data').hide();
            $('#store-list').show();
            $('#store-list').empty();

            removeInput("Add Seller");

            $('#store-list').append('<li data-role="list-divider" id="storeList" class="ui-li-divider ui-bar-a"> Keys: </li>');
            $.each(results.keys, function (index, value) {
                var url = "http://store-api-148707.appspot.com/store/" + value;
                var $newli = $("<li id=" + url + ">&nbsp" + index + ": <span  class = 'link'>" + value + "</span>" +
                    "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp" +
                    "<button class ='delete'>delete</button></li>");
                $('#store-list').append($newli);
            });
        }
    }
    else {
        $('#seller-data').hide();
        $('#error-msg').show();
        $('#error-msg').text("Error retrieving data. ");
    }
}

function showUpdateData(results) {

    $('#sellerAddress1').hide();
    $('#sellerAddress2').hide();
    $('#sellerPhone1').hide();
    $('#sellerMovies1').hide();
    $('#store-list').show();
    $('#seller-data').hide();
    $('#delete').hide();
    $('#error-msg').hide();
    if (results) {


        if (results.movie.length) {
            $('#seller-data').show();
            $('#sellerMovies1').show();
            $('#sellerMovies').empty();
            $('#delete').show();
            $.each(results.movie, function (mindex, mvalue) {
                $('#sellerMovies').append('<option val="' + mvalue + '">' + mvalue + '</option>');
            });
        }

        removeInput("Update Seller");
        $('#post-seller-btn').prop('disabled', true);

        //add results to the bottom of the page
        $('#name').val(results.name);
        $('#name').prop('disabled', true);
        $('#key').val(results.key);
        if (results.phone) {
            $('#phone').val(results.phone);
        }
        $.each(results.address, function (component, value) {
            if (component == 'line1') {
                $('#line1').val(value);
            }
            else if (component == 'line2' && value) {
                $('#line2').val(value);
            }
            else if (component == 'city') {
                $('#city').val(value);
            }
            else if (component == 'state') {
                $('#state').val(value);
            }
            else if (component == 'zipCode') {
                $('#zip').val(value);
            }
            else if (component == 'country') {
                $('#country').val(value);
            }
        });
    }
    else {
        $('#seller-data').hide();
        $('#error-msg').show();
        $('#error-msg').text("Error retrieving data. ");
    }
}

function onGetLocationError(error) {

    $('#error-msg').text('Error getting location');
    $('#post-seller-btn').prop('disabled', false);
}

function showAddressData(results) {

    if (results.results.length) {
        var street = "";
        $('#error-msg').hide();

        $.each(results.results[0].address_components, function (component, value) {
            if (value.types[0] == 'street_number') {
                street = value.short_name;
            }
            else if (value.types[0] == 'route') {
                street = street + " " + value.short_name;
                $('#line1').attr("placeholder", "eg. " + street);
            }
            else if (value.types[0] == 'locality') {
                $('#city').attr("placeholder", "eg. " + value.short_name);
            }
            else if (value.types[0] == 'administrative_area_level_1') {
                $('#state').attr("placeholder", "eg. " + value.short_name);
            }
            else if (value.types[0] == 'country') {
                $('#country').attr("placeholder", "eg. " + value.short_name);
            }
            else if (value.types[0] == 'postal_code') {
                $('#zip').attr("placeholder", "eg. " + value.short_name);
            }
        });

    } else {
        $('#seller-data').hide();
        $('#error-msg').show();
        $('#error-msg').text("Error retrieving data. ");
    }
}

function showSellerData(results) {

    $('#sellerAddress1').hide();
    $('#sellerAddress2').hide();
    $('#sellerPhone1').hide();
    $('#sellerMovies1').hide();
    $('#delete').hide();
    $('#store-list').hide();
    if (results) {
        removeInput("Add Seller");

        if (results.movie.length) {
            $('#sellerMovies1').show();
            $('#delete').hide();
            $('#sellerMovies').empty();
            $.each(results.movie, function (mindex, mvalue) {
                $('#sellerMovies').append('<option val="' + mvalue + '">' + mvalue + '</option>');
            });
        }

        $('#seller-data').show();

        $('#sellertitle').text(results.name);
        $('#key').text(results.key);
        if (results.phone) {
            $('#sellerPhone1').show();
            $('#sellerPhone').text(results.phone);
        }
        $.each(results.address, function (component, value) {
            if (component == 'line1') {
                $('#sellerAddress1').show();
                $('#sellerStreet').text(value);
            }
            else if (component == 'line2' && value) {
                $('#sellerAddress1').show();
                $('#sellerRoute').text(", " + value);
            }
            else if (component == 'city') {
                $('#sellerAddress2').show();
                $('#sellerCity').text(value);
            }
            else if (component == 'state') {
                $('#sellerAddress2').show();
                $('#sellerState').text(", " + value);
            }
            else if (component == 'zipCode') {
                $('#sellerAddress2').show();
                $('#sellerZip').text(value);
            }
            else if (component == 'country') {
                $('#sellerAddress2').show();
                $('#sellerCountry').text(", " + value);
            }
        });

    }
    else {
        $('#seller-data').hide();
        $('#error-msg').show();
        $('#error-msg').text("Error retrieving data. ");
    }
}

function deleteStore(url) {
    removeInput("Add Seller");
    if (url.length) {
        $.ajax({
            type: "DELETE",
            url: url,
            success: function (data) {
                postStoreList();
                alert(data);
            },
            error: function (jqXHR) {
                $('#error-msg').show();
                $('#error-msg').text("Error deleting data. " + jqXHR.statusText);
            }
        });
    }
    else {
        $('#error-msg').show();
        $('#error-msg').text("Error delete requires URL");
    }
    return false;
}

function removeInput(button) {
    //remove values in form
    $('#name').val('');
    $('#name').prop('disabled', false);
    $('#line1').val('');
    $('#line2').val('');
    $('#city').val('');
    $('#state').val('');
    $('#country').val('');
    $('#zip').val('');
    $('#phone').val('');
    $('#key').val(''); //in case of change

    //change value of button
    $('#post-seller-btn').prop('disabled', false);
    $('#post-seller-btn').text(button);
}

function checkState() {
    if ($('#key').length) {
        $('#post-seller-btn').text("Update Seller");
    }
    else {
        $('#post-seller-btn').text("Add Seller");
    }
}

function addStoreMovie() {
    $('#attributes').hide();
    $('#description').hide();
    $('#movie-list').hide();
    //then put movie id into store id
    var mid = encodeURIComponent($('#movie-select').val());
    var key = encodeURIComponent($('#store-select').val());
    if (key.length && mid.length) {
        var storedata = { 'sid': key };
        storedata['mid'] = mid;
        $.ajax({
            accept: "application/json",
            type: "PUT",
            url: 'http://store-api-148707.appspot.com/store/change',
            contentType: "application/x-www-form-urlencoded",
            dataType: "json",
            data: storedata,
            success: function (data) {
                console.log(data);
                showSellerData(data);
            },
            error: function (jqXHR) {
                $('#error-msg-movie').show();
                $('#error-msg-movie').text("Error putting data. " + jqXHR.statusText);
            }
        });
    }
}