import webapp2

app = webapp2.WSGIApplication([
        ('/movie', 'movie.Movie'),
], debug=True)#post a movie
app.router.add(webapp2.Route(r'/movie/<mid:[0-9]+><:/?>', 'movie.Movie')) #get kwargs movie or a list of all movies
app.router.add(webapp2.Route(r'/movie/search', 'movie.MovieSearch')) #post search for a movie by title and/or style
app.router.add(webapp2.Route(r'/movie/change', 'movie.MovieChange')) #change movie through posted price and desc (put)
app.router.add(webapp2.Route(r'/movie/<mid:[0-9]+>/delete', 'movie.MovieDelete')) #delete the kwargs movie
app.router.add(webapp2.Route(r'/store', 'store.Store')) #post a new store
app.router.add(webapp2.Route(r'/store/<sid:[0-9]+><:/?>', 'store.Store')) #get kwargs store or list of all stores
app.router.add(webapp2.Route(r'/store/search', 'store.StoreSearch')) #post search for a store by movie
app.router.add(webapp2.Route(r'/store/change', 'store.StoreChange')) #change/add to store through posted property(not name) (put)
app.router.add(webapp2.Route(r'/store/<sid:[0-9]+>/movie/delete/<mid:[0-9]+><:/?>', 'store.StoreMovieDelete')) #delete the kwargs movie from the kwargs store
app.router.add(webapp2.Route(r'/store/<sid:[0-9]+>/delete', 'store.StoreDelete')) #delete the kwargs store
