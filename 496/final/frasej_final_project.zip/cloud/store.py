import webapp2
from google.appengine.ext import ndb
import db_models
import json
import urllib

class Store(webapp2.RequestHandler):
        def post(self):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("API only accepts json")
                        return
                new_address = db_models.Address()
                new_store = db_models.Stores()
                username = self.request.get('username', default_value=None)
                password = self.request.get('password', default_value=None)
                line1 = self.request.get('line1', default_value=None)
                line2 = self.request.get('line2', default_value=None)
                city = self.request.get('city', default_value=None)
                state = self.request.get('state', default_value=None)
                zipCode = self.request.get('zipCode', default_value=None)
                country = self.request.get('country', default_value=None)
                name = self.request.get('name', default_value=None)
                phone = self.request.get('phone', default_value=None)
                movies = self.request.get_all('movies[]', default_value=None)
                if username:
                        new_store.username = username
                else:
                        self.response.status = 400
                        self.response.write("username is required")
                        return
                if password:
                        new_store.password = password
                else:
                        self.response.status = 400
                        self.response.write("password is required")
                        return
                if name:
                        new_store.name = urllib.unquote(name).decode()
                else:
                        self.response.status = 400
                        self.response.write("seller name is required")
                        return
                if movies:
                        for movie in movies:
                                new_movie = ndb.Key(db_models.Movies, int(movie))
                                if not new_movie.get():
                                        self.response.status = 404
                                        self.response.write("Movie not found")
                                        return
                                new_store.movie.append(new_movie)
                if phone:
                        new_store.phone = phone
                if line1 and city and state and zipCode and country:
                        new_address.line1 = urllib.unquote(line1).decode()
                        new_address.city = urllib.unquote(city).decode()
                        new_address.state = urllib.unquote(state).decode()
                        new_address.zipCode = urllib.unquote(zipCode).decode()
                        new_address.country = urllib.unquote(country).decode()
                        if line2:
                                new_address.line2 = urllib.unquote(line2).decode()
                        new_store.address = new_address
                        
                key = new_store.put()
                out = new_store.to_dict()
                self.response.write(json.dumps(out))
                return

        def get(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("API only accepts json")
                        return
                if 'sid' in kwargs:
                        out = ndb.Key(db_models.Stores, int(kwargs['sid'])).get().to_dict()
                        self.response.write(json.dumps(out))
                else:
                        q = db_models.Stores.query()
                        keys = q.fetch(keys_only=True)
                        results = { 'keys' : [x.id() for x in keys]}
                        self.response.write(json.dumps(results))

class StoreSearch(webapp2.RequestHandler):
        def post(self):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                q = db_models.Stores.query()
                if self.request.get('username',None):
                        q = q.filter(db_models.Stores.username == self.request.get('username'))
                else:
                        self.response.status = 400
                        self.response.write("Bad Request - username is required")
                        return 
                if self.request.get('password',None):
                        q = q.filter(db_models.Stores.password == self.request.get('password'))
                else:
                        self.response.status = 400
                        self.response.write("Bad Request - password is required")
                        return 
                if self.request.get('mid',None):
                        q = q.filter(db_models.Stores.movie == ndb.Key(db_models.Movies, int(self.request.get('mid'))))
                keys = q.fetch(keys_only=True)
                results = { 'keys' : [x.id() for x in keys]}
                self.response.write(json.dumps(results))

class StoreChange(webapp2.RequestHandler):
        def put(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("API only accepts json")
                        return
                if self.request.get('sid', default_value=None):
                        store = ndb.Key(db_models.Stores, int(self.request.get('sid'))).get()
                        if not store:
                                self.response.status = 404
                                self.response.write("Store not found")
                                return
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- store is required")
                        return
                if self.request.get('mid', default_value=None):
                        movie = ndb.Key(db_models.Movies, int(self.request.get('mid')))
                        if not movie.get():
                                self.response.status = 404
                                self.response.write("Movie not found")
                                return
                        if movie not in store.movie:
                                store.movie.append(movie)
                if self.request.get('phone', default_value=None):
                        store.phone = urllib.unquote(self.request.get('phone')).decode()
                if self.request.get('line1', default_value=None):
                        if self.request.get('city', default_value=None):
                                if self.request.get('state', default_value=None):
                                        if self.request.get('zipCode', default_value=None):
                                                if self.request.get('country', default_value=None):
                                                        new_address = db_models.Address()
                                                        new_address.line1 = urllib.unquote(self.request.get('line1')).decode()
                                                        new_address.city = urllib.unquote(self.request.get('city')).decode()
                                                        new_address.state = urllib.unquote(self.request.get('state')).decode()
                                                        new_address.zipCode = urllib.unquote(self.request.get('zipCode')).decode()
                                                        new_address.country = urllib.unquote(self.request.get('country')).decode()
                                                        if self.request.get('line2', default_value=None):
                                                                new_address.line2 = urllib.unquote(self.request.get('line2')).decode()
                                                        store.address = new_address
                        
                store.put()
                self.response.write(json.dumps(store.to_dict()))
                return

class StoreMovieDelete(webapp2.RequestHandler):
        def delete(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                if 'sid' in kwargs:
                        store = ndb.Key(db_models.Stores, int(kwargs['sid'])).get()
                        if not store:
                                self.response.status = 404
                                self.response.write("Store not found")
                                return
                if 'mid' in kwargs:
                        movie = ndb.Key(db_models.Movies, int(kwargs['mid']))
                        if movie in store.movie:
                                store.movie.remove(movie)
                        else:
                                self.response.status = 404
                                self.response.write("Movie not in store")
                                return
                store.put()
                self.response.write(json.dumps(store.to_dict()))
        
class StoreDelete(webapp2.RequestHandler):
        def delete(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                if 'sid' in kwargs:
                        store_key = ndb.Key(db_models.Stores, int(kwargs['sid']))
                        if not store_key.get():
                                self.response.status = 404
                                self.response.write("Store not found")
                                return
                store_key.delete()
                self.response.write("deleted " + kwargs['sid'])
                return
