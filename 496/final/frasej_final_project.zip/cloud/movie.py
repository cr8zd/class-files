import webapp2
from google.appengine.ext import ndb
import db_models
import json

class Movie(webapp2.RequestHandler):
        def post(self):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                new_movie = db_models.Movies()
                username = self.request.get('username', default_value=None)
                password = self.request.get('password', default_value=None)
                title = self.request.get('title', default_value=None)
                style = self.request.get('style', default_value=None)
                price = self.request.get('price', default_value=None)
                desc = self.request.get('desc', default_value=None)
                if username:
                        new_movie.username = username
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- username is required")
                        return
                if password:
                        new_movie.password = password
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- password is required")
                        return
                if title:
                        new_movie.title = title
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- title is required")
                        return
                if style:
                        new_movie.style = style
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- style is required")
                        return
                if price:
                        new_movie.price = price
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- price is required")
                        return
                if desc:
                        new_movie.desc = desc
                key = new_movie.put()
                out = new_movie.to_dict()
                self.response.write(json.dumps(out))
                return

        def get(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                if 'mid' in kwargs: #get info for supplied movie id
                        out = ndb.Key(db_models.Movies, int(kwargs['mid'])).get().to_dict()
                        self.response.write(json.dumps(out))
                else: #get all movie ids
                        q = db_models.Movies.query()
                        keys = q.fetch(keys_only=True)
                        results = { 'keys' : [x.id() for x in keys]}
                        self.response.write(json.dumps(results))

        
class MovieSearch(webapp2.RequestHandler):
        def post(self):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                q = db_models.Movies.query()
                if self.request.get('username',None):
                        q = q.filter(db_models.Movies.username == self.request.get('username'))
                else:
                        self.response.status = 400
                        self.response.write("Bad Request - username is required")
                        return 
                if self.request.get('password',None):
                        q = q.filter(db_models.Movies.password == self.request.get('password'))
                else:
                        self.response.status = 400
                        self.response.write("Bad Request - password is required")
                        return 
                if self.request.get('title',None):
                        q = q.filter(db_models.Movies.title == self.request.get('title'))
                if self.request.get('style',None):
                        q = q.filter(db_models.Movies.style == self.request.get('style'))
                keys = q.fetch(keys_only=True)
                results = { 'keys' : [x.id() for x in keys]}
                self.response.write(json.dumps(results))

class MovieChange(webapp2.RequestHandler):
        def put(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                if self.request.get('mid', default_value=None):
                        movie = ndb.Key(db_models.Movies, int(self.request.get('mid'))).get()
                        if not movie:
                                self.response.status = 404
                                self.response.write("Movie not found")
                                return
                else:
                        self.response.status = 400
                        self.response.write("Bad Request- movie is required")
                        return
                if self.request.get('price', default_value=None):
                        movie.price = self.request.get('price')
                if self.request.get('desc', default_value=None):
                        movie.desc = self.request.get('desc')
                movie.put()
                self.response.write(json.dumps(movie.to_dict()))
                return

class MovieDelete(webapp2.RequestHandler):
        def delete(self, **kwargs):
                if 'application/json' not in self.request.accept:
                        self.response.status = 406
                        self.response.write("Not Acceptable- API only support application/json")
                        return
                if 'mid' in kwargs:
                        movie_key = ndb.Key(db_models.Movies, int(kwargs['mid']))
                        if not movie_key.get():
                                self.response.status = 404
                                self.response.write("Movie not found")
                                return

                q = db_models.Stores.query()
                q = q.filter(db_models.Stores.movie == ndb.Key(db_models.Movies, int(kwargs['mid']))) #filter to the list of stores that have the removed movie
                keys = q.fetch(keys_only=True) #get the stores' keys
                for x in keys: #for every store in the list of keys, get the store and remove from the list of movies the mid of the removed movie
                        store = x.get()
                        store.movie.remove(movie_key)
                        store.put()
                        
                movie_key.delete()
                self.response.write("deleted " + kwargs['mid'])
                return
