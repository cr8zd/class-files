from google.appengine.ext import ndb

class Model(ndb.Model):
        def to_dict(self):
                d = super(Model, self).to_dict()
                d['key'] = self.key.id()
                return d

class Address(Model):
        line1 = ndb.TextProperty(required=True)
        line2 = ndb.TextProperty()
        city = ndb.TextProperty(required=True)
        state = ndb.TextProperty(required=True)
        zipCode = ndb.StringProperty(required=True)
        country = ndb.TextProperty(required=True)
        
class Stores(Model):
        username = ndb.StringProperty(required=True)
        password = ndb.StringProperty(required=True)
        name = ndb.TextProperty(required=True)
        address = ndb.StructuredProperty(Address)
        phone = ndb.TextProperty()
        movie = ndb.KeyProperty(repeated=True)

        def to_dict(self):
                d = super(Stores, self).to_dict()
                d['movie'] = [p.id() for p in d['movie']]
                return d

class Movies(Model):
        username = ndb.StringProperty(required=True)
        password = ndb.StringProperty(required=True)
        title = ndb.StringProperty(required=True)
        style = ndb.StringProperty(required=True)
        price = ndb.StringProperty(required=True)
        desc = ndb.TextProperty()
