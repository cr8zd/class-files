<div id="footer">
			<p> Save the Bees! Project B <?php echo date('Y'); ?></p>
		</div>
	</div><!--end container-->
</body>

</html>