<?php 
	$pageTitle = "Save the Bees! Homepage";
	include('inc/header.php'); 
?>
			<div id="intro">
				<h2>'Save the Bees' is all about well... Saving bees.</h2>
				<p>Project B, site information goes here.</p>
			</div>

<?php include('inc/footer.php'); ?>