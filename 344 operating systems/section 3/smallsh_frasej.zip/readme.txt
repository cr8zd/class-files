HOW TO COMPILE:

type into the bash prompt on the eos server:
   gcc -o smallsh smallch.c
