/* ************************************************************************
   Name: Jennifer Frase
   CSS 344 smallsh
   creates a shell where change directory (cd), status, and exit are built
   into the shell. The user can redirect to other files (< or >) and allow
   for background processes (&). All "word" including the above symbols
    must be seperated by a space.*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <signal.h>

int DEBUG_SMSH = 0; //1 to show printf statements for debug
int BACK_PID[10] = {0};//storage for the last background process PID
int BACK_PID_THERE = 0;
int STATUS = -1;//storage for the last foreground child process's status



void getPrompt(int);
int executeFork(char**, char*, char*, int);
void getStatus(int);
void handleSignal(int, siginfo_t*, void*);

int main ()
{
    getPrompt(STATUS);

    return(0);
}

/* gets the command line from the user, parses it and executes it
   if the request is built-in it is run inside the function
   otherwise the function calls executeFork to try and run it*/
void getPrompt(int status)
{
    char s[2048]; //stores input - s is for string
    char prompt[2048]; /*copy of s used to tokenize; allows for s to remain
                        the original input since strtok alters the string*/
    char** commandLine = (char**)malloc(512 * sizeof(char*));/*array of the
            individual "words" in the prompt*/
    int i = 0; //counter used to increment the index in commandLine
    int bckgrd = 0; /*used to see if process is in the background; allows
            for easy access to see if the & character is in prompt*/
    int input = 0; /*used to see if we are getting input from a file; allow
            for easy access to see if an input file is in prompt*/
    int output = 0; /*used to see if we are sending output to a file; allow
            for easy access to see if an output file is in prompt*/
    char* inputFile = NULL; /* storage for the input File*/
    char* outputFile = NULL; /* storage for the output File*/

    //used to debug so that I can see what directory I am in
    if(DEBUG_SMSH){
        char cwd[1024]; //storage for current working directory
        if (getcwd(cwd, sizeof(cwd)) != NULL)
            printf("Current working dir: %s\n", cwd);
        else
            perror("getcwd() error");
    }

    printf(":");
    fflush(stdout);
    fgets(s, 2048, stdin);


    /*tokenize prompt so that the individual "words" can be used as needed
      most will be stored in commandLine, but <, > and any word that comes
      after will be stored as NULL in commandLine and their value stored
      in separate variables, & will also be made NULL in commandLine*/
    strcpy(prompt, s);
    char* token = strtok(prompt, " \n");
    while (token) {
        if(i == 0 && !strcmp(token, "#")){
            /*first word is # so set commandLine to NULL so that the line
             is ignored*/
            commandLine[i] = NULL;
        }
        else if(!strcmp(token, "<")){
            commandLine[i] = NULL;
            input = 1;//there is an input file after this so mark it
        }
        else if(!strcmp(token, ">")){
            commandLine[i] = NULL;
            output = 1; //there is an output file after this so mark it
        }
        else if(input){
            commandLine[i] = NULL;
            inputFile = token; //save the file name
            input = 0; //mark input false so that if output is after it,
                       //this doesn't catch it instead
        }
        else if(output){
            commandLine[i] = NULL;
            outputFile = token; //save the file name
            output = 0;//mark output false so that it is clear input goes
                       //to the right place
        }
        else if(!strcmp(token, "&")){
            commandLine[i] = NULL;
            bckgrd = 1; //there is an output file after this so mark it
        }
        else{
            commandLine[i] = token;
        }

        //used to debug so that I can see what i is with what token
        if(DEBUG_SMSH)
            printf("i: %d & token: '%s'\n", i, token);
        token = strtok(NULL, " \n");
        i++;
    }

    commandLine[i] = NULL; //make the "last" part of the command line NULL

    /*Deal with the built-ins first if they weren't called then send the
      commandLine to executeFork*/
    if(!commandLine[0]){//blank line or comment do nothing
        free(commandLine);
        getPrompt(STATUS);
    }
    else if(!strcmp(commandLine[0], "exit")){
        //loop through all the back pids and kill them
        while(BACK_PID_THERE){

            kill(BACK_PID[BACK_PID_THERE - 1], SIGKILL);
            BACK_PID_THERE--;
        }
        free(commandLine);
        exit(0); // exit the program
    }
    else if(!strcmp(commandLine[0], "cd")){
        /*if there was an argument after cd then change to that argument
          otherwise set the path to the HOME environment variable*/
        if(commandLine[1])
            chdir(commandLine[1]);
        else
            chdir(getenv("HOME"));
        free(commandLine);
        getPrompt(STATUS);
    }
    else if(!strcmp(commandLine[0], "status")){
        getStatus(STATUS);
    }
    else{
        //if the child process is foreground save the status
        //else save the background PID
        if(!bckgrd)
            STATUS = executeFork(commandLine, inputFile, outputFile, bckgrd);
        else{
            BACK_PID[BACK_PID_THERE] = executeFork(commandLine, inputFile, outputFile, bckgrd);
            BACK_PID_THERE++;
        }
    }

    if(DEBUG_SMSH)
        printf("status: %d", STATUS);
    free(commandLine);
    getPrompt(STATUS);
}

/* creates child processes which can either be the background or the
   foreground process depending on bckgrd. The child process can redirect
   stdin to inFile and stdout to outFile (if no outFile specified on
   background process will redirect to /dev/null)
   inFile and outfile are a file names
   bckgrd is false if set to 0*/
int executeFork(char** commandLine, char* inputFile, char* outputFile, int bckgrd){
    pid_t spawnpid = -5;
    int exitMethod;

    //create a signal handler so that control C only kills background
    //processes and not the shell
    struct sigaction cc_act, normal_act;
    cc_act.sa_handler = SIG_IGN;

    //create a signal handler so that when a background child exits or
    //terminates waitpid is called to terminate it
    struct sigaction sc_act;
    sc_act.sa_handler = handleSignal;
    sc_act.sa_flags = SA_SIGINFO | SA_RESTART;
    sigfillset(&(sc_act.sa_mask));

    //create a fork and save the child's pid for the parent (0 for child)
    spawnpid = fork();
    if(spawnpid == -1){
        printf("fork failed\n");
        perror("fork()\n");
        exit(1);
    }
    else if (spawnpid == 0){

        //Used for debug to make sure which process is which
        int childPID = getpid();
        if(DEBUG_SMSH)
            printf("\n\nI am the child PID = %d\n", childPID);

        //if user specifies an input file, open it and redirect the
        //stdin to input file
        if(inputFile){
            int fd = open(inputFile, O_RDONLY);
            if (fd == -1)
            {
                printf("smallsh: cannot open %s for input\n", inputFile);
                exit(1);
            }
            dup2(fd, 0);// redirect; 0 is stdin
            close(fd);
        }

        //if the user specifies an output file, open it and redirect
        //the stdout to the output file
        if(outputFile || bckgrd){
            if(!outputFile){
                outputFile = "/dev/null";
            }
            int fd = open(outputFile, O_WRONLY|O_CREAT|O_TRUNC, 0644);

            if (fd < 0)
            {
                printf("smallsh: cannot open %s for output\n", outputFile);
                exit(1);
            }
            dup2(fd, 1);//redirect; 1 is stdout
            close(fd);
        }

        /*commandLine is an array so use the 'v' version of exec
          the program we are looking for isn't in our file most likely
          so we are using the path version of exec*/
        execvp(commandLine[0], commandLine);

        fflush(stdout);
        perror("badfile");
        exit(1);
    }
    else{
        //register the sigaction for all parent processes
        //makes the shell ignore control c, but allows the foreground process
        //to still exit
        sigaction(SIGINT, &cc_act, &normal_act);

        //if the child process is not a background process, then call waitpid
        //otherwise set the sigaction call to look for SIGCHLD
        if(!bckgrd){

            //call waitpid to terminate the child with the id that was returned
            //by fork to the parent process
            pid_t exitpid = waitpid(spawnpid, &exitMethod, 0);
            if(exitpid == -1){
                perror("wait failed");
                exit(1);
            }

            //stop ignoring control c
            sigaction(SIGINT, &normal_act, NULL);

            //used to debug to make sure what process is doing what
            int parentPID = getpid();
            if(DEBUG_SMSH)
                printf("\n\nI am the parent! PID = %d\n", parentPID);

            return exitMethod;
        }
        else{
            //register the sigchld signal handler so child get terminated
            sigaction(SIGCHLD, &sc_act, NULL);
            printf("background PID is %d\n", spawnpid);

            fflush(stdout);
            return spawnpid;
        }

    }
}

/* Prints out the status of the child process whose status was saved by wait
   If the program exits normally the exit value is give, otherwise the
   termination value is given*/
void getStatus(int status){
    int exitStatus;
    //makes sure that it is a child's status that is displayed
    if(status == -1){
        printf("no child process started\n");
    }
    else if(WIFEXITED(status)){ //if exit normally get the exit status
        exitStatus = WEXITSTATUS(status);
        printf("exit value %d\n", exitStatus);
    }
    else{ //otherwise get the termination value
        if(DEBUG_SMSH)
            printf("Child terminated by a signal\n");

        /* only call WTERMSIG if WIFSIGNALED is true, which should
           always be the case since we entered the else, but if there
           is a bug this will catch it*/
        if(WIFSIGNALED(status)){
            exitStatus = WTERMSIG(status);
            printf("terminated by signal %d\n", exitStatus);
        }
        else{
            printf("parent process says child didn't exit normally or by signal\n");
            exit(1);
        }
    }
}

/* checks that the signal recieved by the handler is the right pid and then
   calls wait so that the child is killed*/
void handleSignal(int sig, siginfo_t *si, void *context)
{
    int i;
    int there = 0;

    //search through the back pid's stored if the signal's pid matches
    //then wait for it and shift all subseqent pids forward in the
    //array
    for(i = 0; i < BACK_PID_THERE; i++){
        //already found the matching PID so shift all the rest
        if(there){
            BACK_PID[i - 1] = BACK_PID[i]; //eleminates the killed process
        }
        else if(si->si_pid == BACK_PID[i]){
            int status;
            //wait(&status);
            waitpid(BACK_PID, &status, 0);
            printf("background PID %d is done:", si->si_pid);
            there = 1;
            getStatus(status);
        }
    }
    BACK_PID_THERE--; //decrease the number of stored PIDS
}
