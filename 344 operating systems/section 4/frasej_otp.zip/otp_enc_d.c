/*Jennifer Frase
Assignment 4 OTP
CSS 344-400
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <signal.h>

#define BUFSIZE 2048

char* getText(int sockfd, int length);
void handleSignal(int, siginfo_t*, void*);
void encryptText(char* text, char* key, int length);

int main(int argc, char* argv[]) {
    socklen_t clientLength; //number of bytes in client
    struct sockaddr_in server, client; //structs to start/connect to sockets with
    int sockfd; //file descriptor for the socket used to communicate with enc
    int initsockfd; //socket file descriptor that will be used to initiate communication
    int portnum; //port number enc_d listens on
    char buffer[BUFSIZE]; //used to transfer text
    char* text; //file descriptor for the text being encrypted
    char* key; //file descriptor for the text used to encrypt
    int childPID; // storage for the child's pid
    int textLength; //length of text
    int keyLength; //length of key
    int n, transfered = 0;

    if (argc < 2) {
        printf("Usage: otp_enc_d [portNumber]\n");
        exit(1);
    }

    portnum = atoi(argv[1]);

    //set up the server
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(portnum);
    initsockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (initsockfd < 0) {
        perror("ERROR: enc_d create socket");
        exit(1);
    }

    //bind the listening socket to the server
    if ( bind(initsockfd, (struct sockaddr*) &server, sizeof(server)) < 0 ) {
        perror("ERROR: enc_d bind socket");
        exit(1);
    }

    listen(initsockfd, 5);

    //when a connection is made fork and the child process will handle all decryption
    //the parent process will simply set up a sig handler for when a child dies before repeating
    while (1) {

        struct sigaction sc_act;
        sc_act.sa_handler = handleSignal;
        sc_act.sa_flags = SA_SIGINFO | SA_RESTART;
        sigfillset(&(sc_act.sa_mask));

        //get the next incoming connection
        clientLength = sizeof(client);
        sockfd = accept(initsockfd, (struct sockaddr*) &client, &clientLength);
        if (sockfd < 0) {
            perror("ERROR: enc_d accept connection");
        }

        //fork, saving the child's pid
        childPID = fork();
        if(childPID == -1) {
            perror("ERROR: enc_d fork");
        }else if(childPID == 0){//child decrypts

            close(initsockfd);
            memset(buffer, '\0', sizeof(buffer));/*NOTE FOR ME: this will fill the buffer with \0 characters
                                                    Makes it nice so that anything read into it always
                                                    ends in a null*/

            /*get the connection confirmation, so that only dec can connect to
              this program, if connection is not to dec, reports back that the
              connection is denied otherwise it sends that this is dec_d*/
            n = read(sockfd, buffer, sizeof(buffer)-1);
            if (n < 0) {
                perror("ERROR: enc_d read confirmation");
                _exit(1);
            }
            if (strcmp(buffer, "enc") != 0) {
                char response[]  = "denied";
                write(sockfd, response, sizeof(response));
                _exit(2);
            } else {
                char response[] = "enc_d";
                n = write(sockfd, response, sizeof(response));
                if (n < 0) {
                    perror("ERROR: enc_d writing response");
                    _exit(1);
                }
            }

            memset(buffer, '\0', sizeof(buffer));

            //get the length of text file and then get the text
            n = read(sockfd, buffer, sizeof(buffer));
            if (n < 0) {
                perror("ERROR: enc_d read textLength");
                _exit(1);
            }
            textLength = atoi(buffer);
            text = getText(sockfd, textLength);

            memset(buffer, '\0', sizeof(buffer));

            //get the length of the key file and then get the text
            n = read(sockfd, buffer, sizeof(buffer));
            if (n < 0) {
                perror("ERROR: enc_d read keyLength");
                _exit(1);
            }
            keyLength = atoi(buffer);
            key = getText(sockfd, keyLength);


            encryptText(text, key, textLength);

            //write the encrypted text back to dec
            transfered = 0;
            while(transfered < textLength){
                n = write(sockfd, text + transfered, textLength - transfered);
                if (n < 0) {
                    perror("ERROR: enc_d write cipher");
                    _exit(1);
                }
                transfered += n;
            }

            //free the variables malloced in getText
            free(text);
            free(key);

            _exit(0);
        }else{

            close(sockfd);
            //set up sig handler
            sigaction(SIGCHLD, &sc_act, NULL);
        }
    }
    close(initsockfd);
    return 0;
}

/*check to see if any children have exited so that is can clean
  up, making sure they don't stay defunct*/
void handleSignal(int sig, siginfo_t *si, void *context)
{
    int childPID; //storage for a defunct child from fork or 0 if there are none
    int status; //status of defunct child
    do {
        childPID = waitpid(-1, &status, WNOHANG);
    } while (childPID > 0);
}

/*takes a socket file descriptor and a length, it will then get length of
  text from the socket before telling dec that it is done receiving the text
  and so can continue*/
char* getText(int sockfd, int length) {
    char* str; //storage for the text we are receiving
    char response[] = "done"; //message to tell dec to continue
    int n; //used to check if read and write produce
    int transfered = 0; //used to see if read got all the data

    str = (char*)malloc(length);

    //loops until we have received all the data
    while(transfered < length){
        n = read(sockfd, str + transfered, length - transfered);
        if (n < 0) {
            perror("ERROR: enc_d read text");
            _exit(1);
        }
        transfered += n;
    }
    //tells dec that dec_d is done reading and so can continue
    n = write(sockfd, response, strlen(response));
    if (n < 0) {
        perror("ERROR: enc writing done");
        exit(1);
    }
    return str;
}

/*takes three variables where the first two are char pointers that go to the
text being encrypted and the other is the text used to encrypt. The last variable
is length of the first file*/
void encryptText(char* text, char* key, int length){
    int cipherLetter, keyLetter, textLetter;//storage for a single character from text and key
                                             //used to encrypt text

    for (int i = 0; i < length; ++i) {
        //ignore newline character
        if (text[i] != '\n') {
            //convert cipher character to ints
            if (text[i] == ' ') {
                textLetter = 26;
            } else {
                textLetter = text[i] - 'A';
            }

            //convert key characters to ints
            if (key[i] == ' ') {
                keyLetter = 26;
            } else {
                keyLetter = key[i] - 'A';
            }

            //determine the decrypted characters
            cipherLetter = (textLetter + keyLetter) % 27;
            if (cipherLetter == 26) {
                text[i] = ' ';
            } else {
                text[i] = cipherLetter + 'A';
            }
        }
    }
}
