/*Jennifer Frase
Assignment 4 OTP
CSS 344-400
*based on the client server code provided in the section as well as man pages
things like memset which i found through the bzero man page
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>

#define BUFSIZE 2048

void sendText(int fd, int sockfd, int length);

int main(int argc, char* argv[]) {
    int sockfd; //file descriptor for the socket used to communicate with enc_d
    int portnum; //port number enc will be looking to connect to enc_d on
    int textFile; //file descriptor that contains the text to be encrypted
    int keyFile; // file descriptor that contains the key text
    struct sockaddr_in server; //used to make the socket
    struct hostent* serv_addr; //used to make the socket on the server
    char buffer[BUFSIZE];//used to transfer text
    int textLength; //length of the text file
    int keyLength; //length of the key file
    int n = 0; //used to see if there was a problem writing the encrypted text
    int transfered = 0;

    if (argc < 4) {
        printf("Usage: otp_enc [textFile] [keyFile] [portNumber]\n");
        exit(1);
    }

    //get the command line arguments and for the first two open them
    textFile = open(argv[1], O_RDONLY);
    keyFile = open(argv[2], O_RDONLY);
    if (textFile < 0 || keyFile < 0) {
        perror("ERROR: enc file open");
        exit(1);
    }
    portnum = atoi(argv[3]);

    //get the length of the cipher and key and make sure key is long enough
    textLength = lseek(textFile, 0, SEEK_END);
    keyLength = lseek(keyFile, 0, SEEK_END);
    if (keyLength < textLength) {
        perror("ERROR: enc key is too short");
        exit(1);
    }
    lseek(textFile, 0, SEEK_SET);
    lseek(keyFile, 0, SEEK_SET);

    //loop through all the letters and check that each is valid
    while(transfered < textLength){
        n = read(textFile, buffer, 1);
        if(n < 0)
        {
            perror("ERROR: dec reading character from file");
            exit(1);
        }
        transfered += n;
        if (buffer[0] != ' ' && (buffer[0] < 'A' || buffer[0] > 'Z') && buffer[0] != '\n') {
            perror("ERROR: enc text contains invalid characters");
            exit(1);
        }
    }

    lseek(textFile, 0, SEEK_SET);
    //set up the server connection
    serv_addr = gethostbyname("localhost");
    if (serv_addr == NULL) {
        perror("ERROR: enc server ip");
        exit(1);
    }
    server.sin_family = AF_INET;
    server.sin_port = htons(portnum);
    memcpy(&server.sin_addr, serv_addr->h_addr, serv_addr->h_length);

    //create the socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("ERROR: enc create socket");
        exit(1);
    }

    //connect to enc_d
    if (connect(sockfd, (struct sockaddr*) &server, sizeof(server))) {
        perror("ERROR: enc connect server");
        exit(2);
    }

    memset(buffer, '\0', sizeof(buffer));/*NOTE FOR ME: this will fill the buffer with \0 characters
                                                    Makes it nice so that anything read into it always
                                                    ends in a null*/


    //send an authentication message so make sure the port is for enc_d
    char confirm[] = "enc";
    n = write(sockfd, confirm, sizeof(confirm));
    if (n < 0) {
        perror("ERROR: enc writing confirmation");
        _Exit(1);
    }
    n = read(sockfd, buffer, sizeof(buffer));
    if (n < 0) {
        perror("ERROR: enc reading confirmation");
        _Exit(1);
    }
    if (strcmp(buffer, "enc_d") != 0) {
        perror("ERROR: enc unable to contact otp_enc_d on given port");
        exit(2);
    }

    //send the cipher and key texts
    sendText(textFile, sockfd, textLength);
    sendText(keyFile, sockfd, keyLength);

    memset(buffer, '\0', sizeof(buffer));

    //get the encrypted text back to enc_d
    transfered = 0;
    while(transfered < textLength){
        n = read(sockfd, buffer, sizeof(buffer)-1);
        if (n < 0) {
            perror("ERROR: enc read cipher");
            _Exit(1);
        }
        buffer[n] = '\0';
        printf("%s", buffer);
        transfered += n;
    }

    close(textFile);
    close(keyFile);
    close(sockfd);

    return 0;
}

/*takes three variables, two file descriptors which point to a file to be read
  from and a socket to write toward. The third is the length of the text in the
  first file descriptor*/
void sendText(int fd, int sockfd, int length) {
    char buffer[BUFSIZE]; //used to transfer text
    int r = 10, w; //number of bytes read and written respectively

    //make sure enc_d knows how big the text we are sending is
    sprintf(buffer, "%d", length);
    w = write(sockfd, buffer, strlen(buffer));
    if (w < 0) {
        perror("ERROR: enc writing text length");
        exit(1);
    }
    //loop until read can no longer read from the file
    while (r != 0) {
        r = read(fd, buffer, sizeof(buffer));
        if (r < 0) {
            perror("ERROR: enc reading text from file");
            exit(1);
        }

        //loop until all that was just read is sent to enc_d
        int transfered = 0;
        while(transfered < r){
            w = write(sockfd, buffer + transfered, r - transfered);
            if (w < 0) {
                perror("ERROR: enc writing text to socket");
                exit(1);
            }
            transfered += w;
        }
    }
    memset(buffer, '\0', BUFSIZE);

    //wait until enc_d is done receiving text and sends a message saying so
    r = read(sockfd, buffer, BUFSIZE - 1);
    if (r < 0) {
        perror("ERROR: enc reading text confirmation");
    }
}
