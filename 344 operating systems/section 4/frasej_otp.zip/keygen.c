/*Jennifer Frase
Assignment 4 OTP
CSS 344-400
*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char* argv[]) {
    int keylength; //length that is requested
    int num; //a random number
    char ch; //a random character

    if (argc < 2) {
        printf("Usage: keygen [file length]");
        exit(1);
    }

    //convert the argument string to an integer
    keylength = atoi(argv[1]);

    srand(time(NULL));

    //get a random number * keyLength and print to stdout
    for(int i = 0; i < keylength; i++){
        num = rand() % 27;
        printf("%c", (num == 26? ' ': num + 'A'));
    }

    printf("\n");

    return 0;
}
